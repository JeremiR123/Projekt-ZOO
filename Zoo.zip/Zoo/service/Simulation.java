package service;
import java.util.List;

import Domain.*;

public class Simulation{
    private List<Animal> animals;

    public Simulation(List<Animal> animals) {
    this.animals = animals;
    }

    public void RunSimulation(int liczba_tur){
        int tury = 0; 
        while(liczba_tur > tury)
        {
            tury+=1;
            System.out.println("=-=-=-=-=-=TURA"+ tury+"=-=-=-=-=-=");
            for (Animal animal : animals) {
                System.out.println(animal.eat());
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }    
            }
            System.out.println("");


            try {
            Thread.sleep(1000);
            
            } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
        }      
    }
}
