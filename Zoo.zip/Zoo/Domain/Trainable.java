package Domain;

public interface Trainable {
    default String performTrick(){
        return "Salto";
    } 
}
