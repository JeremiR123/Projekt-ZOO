package Domain;

public interface Flyable {
    default String Fly(){
        return "lece";
    }
}
