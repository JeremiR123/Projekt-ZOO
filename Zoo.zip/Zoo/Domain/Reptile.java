package Domain;

public class Reptile extends Animal implements Swimable, Trainable{
    public String scalesColor;
    
}
