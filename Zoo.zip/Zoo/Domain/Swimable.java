package Domain;

public interface Swimable {
    default String swim(){
        return "chlup chlup chlup";
    }
}
