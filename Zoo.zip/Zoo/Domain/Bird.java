package Domain;

public class Bird extends Animal implements Flyable, Trainable, Swimable{
    public int wingspan;
}
